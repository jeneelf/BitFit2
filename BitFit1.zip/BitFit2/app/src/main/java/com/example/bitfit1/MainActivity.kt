package com.example.bitfit1

import android.os.Bundle

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import com.example.bitfit1.databinding.ActivityMainBinding

class MainActivity : FragmentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        //Bottom Nav
        val navController = supportFragmentManager.beginTransaction()
        navController.replace(R.id.fragmentContainer, WaterEntriesFragment()).commit()

        binding.bottomNavigationView.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_entries -> {
                    val entriesFragment = WaterEntriesFragment()
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.fragmentContainer, entriesFragment)
                        .commit()
                    true
                }
                R.id.nav_dashboard -> {
                    val dashboardFragment = DashboardFragment()
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.fragmentContainer, dashboardFragment)
                        .commit()
                    true
                }
                else -> false
            }
        }
    }
}
