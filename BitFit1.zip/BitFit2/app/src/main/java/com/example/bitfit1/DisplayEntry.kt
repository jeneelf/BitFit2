package com.example.bitfit1

data class DisplayEntry(
    val date: String?,
    val waterAmount: Double,
    val notes: String?
) : java.io.Serializable
