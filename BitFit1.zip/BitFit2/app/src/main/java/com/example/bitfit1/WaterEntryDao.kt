package com.example.bitfit1

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface WaterEntryDao {
    @Insert
    suspend fun insertEntry(entry: WaterEntryEntity)

    @Query("SELECT * FROM water_entries")
    fun getAllEntries(): Flow<List<WaterEntryEntity>>
    @Query("SELECT SUM(quantity) FROM water_entries")
    fun getTotalWater(): Flow<Double>
}