package com.example.bitfit1

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.bitfit1.databinding.EntryItemBinding

class EntryAdapter(private val entries: List<DisplayEntry>) : RecyclerView.Adapter<EntryAdapter.EntryViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EntryViewHolder {
        val binding = EntryItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return EntryViewHolder(binding)
    }

    override fun onBindViewHolder(holder: EntryViewHolder, position: Int) {
        val entry = entries[position]
        holder.bind(entry)
    }

    override fun getItemCount(): Int = entries.size

    inner class EntryViewHolder(private val binding: EntryItemBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(entry: DisplayEntry) {
            binding.dateTextView.text = entry.date
            binding.waterAmountTextView.text = entry.waterAmount.toString()
            binding.notesTextView.text = entry.notes
        }
    }
}
