package com.example.bitfit1

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.bitfit1.databinding.FragmentWaterEntriesBinding
import kotlinx.coroutines.launch

class WaterEntriesFragment : Fragment() {

    private var _binding: FragmentWaterEntriesBinding? = null
    private val binding get() = _binding!!

    private val entries = mutableListOf<DisplayEntry>()
    private lateinit var adapter: EntryAdapter

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentWaterEntriesBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Setup RecyclerView
        adapter = EntryAdapter(entries)
        binding.rvEntries.layoutManager = LinearLayoutManager(requireContext())
        binding.rvEntries.adapter = adapter

        // Database instance
        val db = (requireActivity().application as WaterApplication).db

        // Load data from the database
        lifecycleScope.launch {
            db.waterEntryDao().getAllEntries().collect { databaseList ->
                val mappedList = databaseList.map { entity ->
                    DisplayEntry(entity.date, entity.quantity, entity.notes)
                }
                entries.clear()
                entries.addAll(mappedList)
                adapter.notifyDataSetChanged()
            }
        }

        // Save button click listener
        binding.btnSave.setOnClickListener {
            val date = binding.etDate.text.toString()
            val quantity = binding.etQuantity.text.toString().toDoubleOrNull()
            val notes = binding.etNotes.text.toString()

            Log.d("WaterEntriesFragment", "Save Entry button clicked")
            if (date.isNotBlank() && quantity != null) {
                lifecycleScope.launch {
                    try {
                        val db = (requireActivity().application as WaterApplication).db
                        db.waterEntryDao().insertEntry(
                            WaterEntryEntity(date = date, quantity = quantity, notes = notes)
                        )
                        Log.d("WaterEntriesFragment", "Entry saved successfully")

                        // Clear fields after save
                        binding.etDate.text.clear()
                        binding.etQuantity.text.clear()
                        binding.etNotes.text.clear()

                        Toast.makeText(
                            requireContext(),
                            "Entry saved successfully!",
                            Toast.LENGTH_SHORT
                        ).show()
                    } catch (e: Exception) {
                        Log.e("WaterEntriesFragment", "Error inserting entry: ${e.message}")
                        Toast.makeText(
                            requireContext(),
                            "Failed to save entry. Try again.",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            } else {
                Log.e("WaterEntriesFragment", "Validation failed: Missing date or invalid quantity")
                Toast.makeText(
                    requireContext(),
                    "Please enter a valid date and quantity",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }


        override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}